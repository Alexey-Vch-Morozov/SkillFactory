from django.db import models
from django.contrib.auth.models import User


class Author(models.Model):
    author = models.OneToOneField(User, on_delete=models.CASCADE)
    author_rating = models.IntegerField(default=0)
#    Метод update_rating()
#     def update_rating(self):
# #    Запрашиваем объект QuerySet и преобразуем его в список словарей
#         request = Post.objects.all().values('post_rating')
#         rating = 0
#         for a in range(len(request)-1):
#             x = request[a]
#             rating += int(x.values())
#         self.rating = rating * 3
#         self.save()

#    обновляет рейтинг пользователя, переданный в аргумент этого метода.
#    Он состоит из: суммарный рейтинг каждой статьи автора умножается на 3
#    суммарный рейтинг всех комментариев автора;
#    суммарный рейтинг всех комментариев к статьям автора.

class Category(models.Model):
    category = models.CharField(max_length=255, unique=True)


class Post(models.Model):
    news = 'N'
    article = 'A'
    CATEGORIES = [(news, 'Новость'), (article, 'Статья')]
    # Один ко многим с таблицей Author
    author = models.ForeignKey(Author, on_delete=models.CASCADE)
    # Выбор-статья или новость
    category_selector = models.CharField(max_length=1, choices=CATEGORIES, default=news)
    # Автоматически добавляемая дата и время создания.
    time_add = models.DateTimeField(auto_now_add=True)
    # Многие ко многим с таблицей Category через PostCategory
    post = models.ManyToManyField(Category, through='PostCategory')
    # Заголовок статьи или новости
    header = models.CharField(max_length=255)
    # Текст стати или новости
    text = models.TextField()
    # Рейтинг статьи или новости
    post_rating = models.IntegerField(default=0)

    def like(self):
        self.post_rating += 1
        self.save()

    def dislike(self):
        self.post_rating -= 1
        self.save()

    # method preview() - Возвращает начало статьи длиной 124 символа и добавляет многоточие в конце
    def preview(self):
        preview = self.text[:124] + '...'
        return preview


class PostCategory(models.Model):
    # один ко многим с таблицей Post
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    # один ко многим с таблицей Category
    category = models.ForeignKey(Category, on_delete=models.CASCADE)


class Comment(models.Model):
    # один ко многим с таблицей Post
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    # один ко многим с User
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    # Текст комментария
    comment_text = models.TextField()
    # Автоматически добавляемая дата и время создания
    time_add = models.DateTimeField(auto_now_add=True)
    # Рейтинг комментария
    comment_rating = models.IntegerField(default=0)

    def like(self):
        self.comment_rating += 1
        self.save()

    def dislike(self):
        self.comment_rating -= 1
        self.save()
